import Logo from "./Logo";
import {
  FiHome,
  FiCreditCard,
  FiPieChart,
  FiTarget,
  FiBell,
  FiUser,
  FiSettings,
  FiX,
} from "react-icons/fi";

const menu = [
  { name: "Dashboard", icon: FiHome },
  { name: "Transactions", icon: FiCreditCard },
  { name: "Analytics", icon: FiPieChart },
  { name: "Budgets", icon: FiTarget },
  { name: "Notifications", icon: FiBell },
  { name: "Profile", icon: FiUser },
  { name: "Settings", icon: FiSettings },
];

export default function Sidebar({ closeSidebar }) {
  return (
    <aside className="w-72 bg-white border-r border-slate-200 h-screen p-6 shadow-xl overflow-y-auto">
      {/* Mobile Close Button */}
      <div className="flex items-center justify-between lg:block">
        <Logo />

        <button
          onClick={closeSidebar}
          className="lg:hidden p-2 rounded-lg hover:bg-slate-100"
        >
          <FiX size={24} />
        </button>
      </div>

      <nav className="mt-10 space-y-2">
        {menu.map((item) => {
          const Icon = item.icon;

          return (
            <button
              key={item.name}
              onClick={closeSidebar}
              className="flex items-center gap-4 w-full px-4 py-3 rounded-xl text-slate-700 hover:bg-emerald-50 hover:text-emerald-600 transition-all duration-200"
            >
              <Icon size={20} />
              <span className="font-medium">{item.name}</span>
            </button>
          );
        })}
      </nav>
    </aside>
  );
}