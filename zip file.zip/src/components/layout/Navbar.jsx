import { FiBell, FiMenu, FiSearch } from "react-icons/fi";

export default function Navbar({ openSidebar }) {
  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200">
      <div className="flex items-center justify-between px-4 md:px-6 py-4">
        {/* Left */}
        <div className="flex items-center gap-4">
          <button
            onClick={openSidebar}
            className="lg:hidden p-2 rounded-lg hover:bg-slate-100"
          >
            <FiMenu size={24} />
          </button>

          <h1 className="text-xl md:text-2xl font-bold text-slate-800">
            Dashboard
          </h1>
        </div>

        {/* Right */}
        <div className="flex items-center gap-3">
          <button className="hidden md:flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100">
            <FiSearch />
            <span className="text-sm text-slate-500">Search</span>
          </button>

          <button className="relative p-2 rounded-xl hover:bg-slate-100">
            <FiBell size={22} />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>

          <img
            src="https://ui-avatars.com/api/?name=SS&background=10b981&color=fff"
            alt="Profile"
            className="w-10 h-10 rounded-full"
          />
        </div>
      </div>
    </header>
  );
} 